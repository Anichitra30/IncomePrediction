# INFO-523-FINAL-PROJECT

This dataset is a collection of information on a sample of adults with a list of attributes that we would expect to be recorded during a typical census. The columns give information about gender, salary rate, employment status, educational background, race, marital status and a lot other attributes that can be used to classify individuals and to gain information about the particular population that could eventually help in several ways. For instance, the government could use such information to plan on various social security schemes, imports, budgets and more.
